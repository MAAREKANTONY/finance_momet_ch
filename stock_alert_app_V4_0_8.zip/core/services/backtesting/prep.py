"""
Prerequisites preparation for backtests.

When a backtest is launched, we must ensure:
- DailyBar data is available for the universe and date range (Twelve Data sync)
- DailyMetric + Alert computations are available for the scenario configuration (same computations as alerts)

This module provides a conservative implementation that reuses existing tasks.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Any

from django.db.models import Min, Max

from core.models import Backtest, DailyBar, DailyMetric, Symbol
from core.tasks import fetch_daily_bars_task, compute_metrics_task


@dataclass
class BacktestPrepReport:
    did_fetch_bars: bool
    did_compute_metrics: bool
    notes: list[str]


def _bars_cover_range(symbol_id: int, start: date | None, end: date | None) -> bool:
    if not start or not end:
        return True
    agg = DailyBar.objects.filter(symbol_id=symbol_id).aggregate(min_d=Min("date"), max_d=Max("date"))
    return bool(agg["min_d"] and agg["max_d"] and agg["min_d"] <= start and agg["max_d"] >= end)


def _metrics_cover_range(symbol_id: int, scenario_id: int, start: date | None, end: date | None) -> bool:
    if not start or not end:
        return True
    agg = DailyMetric.objects.filter(symbol_id=symbol_id, scenario_id=scenario_id).aggregate(min_d=Min("date"), max_d=Max("date"))
    return bool(agg["min_d"] and agg["max_d"] and agg["min_d"] <= start and agg["max_d"] >= end)


def prepare_backtest_data(backtest: Backtest) -> BacktestPrepReport:
    """
    Ensure bars + metrics exist for the backtest universe and period.

    Conservative strategy:
    - If any symbol is missing bars for the period -> run global fetch_daily_bars_task()
    - If any symbol is missing metrics for the scenario/period -> run compute_metrics_task(recompute_all=False)

    This may compute more than needed, but is safe and keeps the logic simple for initial iterations.
    """
    notes: list[str] = []
    did_fetch = False
    did_compute = False

    # Universe: use snapshot if present, else scenario symbols
    if backtest.universe_snapshot:
        tickers = [(x.get("ticker"), x.get("exchange")) for x in backtest.universe_snapshot if x.get("ticker")]
        symbols = list(Symbol.objects.filter(ticker__in=[t for t,_ in tickers]).all())
        if not symbols:
            notes.append("Universe snapshot present but no symbols matched in DB; fallback to scenario symbols.")
            symbols = list(backtest.scenario.symbols.all())
    else:
        symbols = list(backtest.scenario.symbols.all())

    # Check bars coverage
    missing_bars = []
    for s in symbols:
        if not _bars_cover_range(s.id, backtest.start_date, backtest.end_date):
            missing_bars.append(s.ticker)
    if missing_bars:
        notes.append(f"Missing DailyBar coverage for {len(missing_bars)} symbol(s): {', '.join(missing_bars[:10])}{'...' if len(missing_bars)>10 else ''}")
        fetch_daily_bars_task()
        did_fetch = True
        notes.append("Ran fetch_daily_bars_task().")

    # Check metrics coverage
    missing_metrics = []
    for s in symbols:
        if not _metrics_cover_range(s.id, backtest.scenario_id, backtest.start_date, backtest.end_date):
            missing_metrics.append(s.ticker)
    if missing_metrics:
        notes.append(f"Missing DailyMetric coverage for {len(missing_metrics)} symbol(s): {', '.join(missing_metrics[:10])}{'...' if len(missing_metrics)>10 else ''}")
        compute_metrics_task(recompute_all=False)
        did_compute = True
        notes.append("Ran compute_metrics_task(recompute_all=False).")

    return BacktestPrepReport(did_fetch_bars=did_fetch, did_compute_metrics=did_compute, notes=notes)
