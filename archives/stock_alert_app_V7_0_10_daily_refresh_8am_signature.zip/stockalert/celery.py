import os
from celery import Celery
from celery.schedules import crontab
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "stockalert.settings")
app = Celery("stockalert")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

app.conf.beat_schedule = {
    'check-scheduled-alerts': {'task':'core.tasks.check_and_send_scheduled_alerts_task','schedule': crontab(minute=0)},
    'cleanup-stale-processing-jobs': {'task':'core.tasks.cleanup_stale_processing_jobs_task','schedule': crontab(minute=0)},
    # Daily end-to-end refresh: bars fetch + scenarios compute + games tables
    'daily-system-refresh': {'task': 'core.tasks.daily_system_refresh_job_task', 'schedule': crontab(hour=8, minute=0)},
}
