from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from django.conf import settings
from django.db import transaction
from django.utils import timezone

import logging

from .job_broker import broker_queue_snapshot
from .models import ProcessingJob

logger = logging.getLogger(__name__)


INLINE_OBVIOUS_RUNNING_STALE_MINUTES = 5
INLINE_OBVIOUS_PENDING_STALE_MINUTES = 15


def find_active_processing_job(*, job_type: str | None = None, game_scenario=None, backtest=None) -> ProcessingJob | None:
    """Return the most recent active tracked job matching the provided owner filters."""
    qs = ProcessingJob.objects.filter(status__in=[ProcessingJob.Status.PENDING, ProcessingJob.Status.RUNNING])
    if job_type:
        qs = qs.filter(job_type=job_type)
    if game_scenario is not None:
        game_id = getattr(game_scenario, "id", game_scenario)
        qs = qs.filter(game_scenario_id=game_id)
    if backtest is not None:
        backtest_id = getattr(backtest, "id", backtest)
        qs = qs.filter(backtest_id=backtest_id)
    return qs.order_by("-id").only("id", "status", "job_type", "game_scenario_id", "backtest_id", "created_at").first()



@dataclass(slots=True)
class TaskDispatchOutcome:
    task_id: str = ""
    dispatch_error: Exception | None = None

    @property
    def launched(self) -> bool:
        return self.dispatch_error is None and bool((self.task_id or "").strip())


@dataclass(slots=True)
class JobLaunchOutcome:
    job: ProcessingJob
    dispatch_error: Exception | None = None

    @property
    def launched(self) -> bool:
        return self.dispatch_error is None and bool((self.job.task_id or "").strip())


class ActiveJobConflictError(RuntimeError):
    """Raised when a new tracked job is requested while another one is still active."""




def _is_obviously_stale_active_job(job: ProcessingJob, *, now) -> bool:
    if job.status == ProcessingJob.Status.RUNNING:
        ref = job.heartbeat_at or job.started_at
        if ref is None:
            return False
        obvious_cutoff = now - timezone.timedelta(minutes=INLINE_OBVIOUS_RUNNING_STALE_MINUTES)
        return ref <= obvious_cutoff
    if job.status == ProcessingJob.Status.PENDING:
        if job.created_at is None:
            return False
        obvious_cutoff = now - timezone.timedelta(minutes=INLINE_OBVIOUS_PENDING_STALE_MINUTES)
        return job.created_at <= obvious_cutoff
    return False

def _recover_stale_active_jobs() -> None:
    """Best-effort inline recovery before rejecting a new launch.

    Goal: avoid keeping the whole queue blocked by a zombie PENDING/RUNNING row
    until the periodic cleanup task runs.

    Important: keep this path intentionally conservative but deterministic. If the
    bulk queryset-based recovery misses an obviously stale active row for any
    reason, we do one last inline pass on the remaining active rows.
    """
    from .job_recovery import apply_recovery, decide_recovery, recover_jobs

    active_ids = list(
        ProcessingJob.objects.filter(status__in=[ProcessingJob.Status.PENDING, ProcessingJob.Status.RUNNING])
        .order_by("id")
        .values_list("id", flat=True)
    )
    if not active_ids:
        return

    hb_minutes = int(getattr(settings, "JOB_STALE_HEARTBEAT_MINUTES", 2))
    started_minutes = int(getattr(settings, "JOB_STALE_STARTED_MINUTES", 3))
    pending_minutes = int(getattr(settings, "JOB_STALE_PENDING_MINUTES", 10))
    requested_minutes = int(getattr(settings, "JOB_REQUESTED_STOP_STALE_MINUTES", 1))

    recover_jobs(
        ids=active_ids,
        running_heartbeat_minutes=hb_minutes,
        running_started_minutes=started_minutes,
        pending_minutes=pending_minutes,
        requested_stop_minutes=requested_minutes,
        include_pending=True,
        include_requested_pending=True,
        dry_run=False,
        sync_recent_terminal=True,
    )

    now = timezone.now()
    hb_cutoff = now - timezone.timedelta(minutes=max(1, hb_minutes))
    started_cutoff = now - timezone.timedelta(minutes=max(1, started_minutes))
    pending_cutoff = now - timezone.timedelta(minutes=max(1, pending_minutes))
    requested_cutoff = now - timezone.timedelta(minutes=max(1, requested_minutes))

    remaining = list(
        ProcessingJob.objects.filter(id__in=active_ids, status__in=[ProcessingJob.Status.PENDING, ProcessingJob.Status.RUNNING])
        .only("id", "status", "created_at", "started_at", "heartbeat_at", "cancel_requested", "kill_requested", "message", "error", "backtest_id", "game_scenario_id")
        .order_by("id")
    )
    for job in remaining:
        is_requested = bool(job.cancel_requested or job.kill_requested)
        is_stale = False
        if job.status == ProcessingJob.Status.PENDING:
            if is_requested:
                is_stale = True
            elif job.created_at and job.created_at <= pending_cutoff:
                is_stale = True
        elif job.status == ProcessingJob.Status.RUNNING:
            ref = job.heartbeat_at or job.started_at
            cutoff = requested_cutoff if is_requested else (hb_cutoff if job.heartbeat_at else started_cutoff)
            if ref and ref <= cutoff:
                is_stale = True
        if not is_stale and _is_obviously_stale_active_job(job, now=now):
            is_stale = True
        if not is_stale:
            continue
        decision = decide_recovery(job, now=now)
        if decision is None:
            continue
        apply_recovery(job, decision, dry_run=False, now=now)


def _build_conflict_outcome(*, job_type: str, message: str, created_by=None, backtest=None, scenario=None, game_scenario=None, active_job: ProcessingJob) -> JobLaunchOutcome:
    err = ActiveJobConflictError(
        f"Another job is already active (job #{active_job.id}, {active_job.job_type}, {active_job.status})."
    )
    job = ProcessingJob.objects.create(
        job_type=job_type,
        status=ProcessingJob.Status.FAILED,
        backtest=backtest,
        scenario=scenario,
        game_scenario=game_scenario,
        created_by=created_by,
        message=message,
        error=str(err),
        finished_at=timezone.now(),
    )
    return JobLaunchOutcome(job=job, dispatch_error=err)


def launch_processing_job(
    *,
    task: Any,
    job_type: str,
    task_kwargs: Mapping[str, Any] | None = None,
    created_by=None,
    backtest=None,
    scenario=None,
    game_scenario=None,
    message: str = "En attente d'exécution",
) -> JobLaunchOutcome:
    """Create a tracked ProcessingJob then enqueue its Celery task after DB commit.

    Sprint P0.1 goals:
    - eliminate scattered create + delay + save(task_id) patterns
    - ensure the task is published only after the ProcessingJob row is committed
    - fail the job explicitly if broker publication raises synchronously
    """
    payload = dict(task_kwargs or {})
    outcome: dict[str, Any] = {}

    now = timezone.now()
    active_job = find_active_processing_job()
    if active_job is not None and _is_obviously_stale_active_job(active_job, now=now):
        from .job_recovery import apply_recovery, decide_recovery

        decision = decide_recovery(active_job, now=now)
        if decision is not None:
            apply_recovery(active_job, decision, dry_run=False, now=now)
        active_job = find_active_processing_job()

    if active_job is not None:
        return _build_conflict_outcome(
            job_type=job_type,
            message=message,
            created_by=created_by,
            backtest=backtest,
            scenario=scenario,
            game_scenario=game_scenario,
            active_job=active_job,
        )

    job = ProcessingJob.objects.create(
        job_type=job_type,
        status=ProcessingJob.Status.PENDING,
        backtest=backtest,
        scenario=scenario,
        game_scenario=game_scenario,
        created_by=created_by,
        message=message,
    )

    def _enqueue() -> None:
        before_snapshot = broker_queue_snapshot(sample_limit=2)
        logger.warning(
            "[job-launch] enqueue start job_id=%s job_type=%s queue=%s queue_len_before=%s samples=%s",
            job.id,
            job_type,
            before_snapshot.queue_name,
            before_snapshot.length,
            before_snapshot.samples,
        )
        try:
            async_result = task.apply_async(kwargs={**payload, "job_id": job.id})
        except Exception as exc:  # pragma: no cover - exercised via tests with mock side effects
            ProcessingJob.objects.filter(id=job.id).update(
                status=ProcessingJob.Status.FAILED,
                error=f"Task dispatch failed: {exc}",
                finished_at=timezone.now(),
            )
            logger.exception("[job-launch] enqueue failed job_id=%s job_type=%s", job.id, job_type)
            outcome["dispatch_error"] = exc
            return

        task_id = (getattr(async_result, "id", "") or "")[:64]
        ProcessingJob.objects.filter(id=job.id).update(task_id=task_id)
        after_snapshot = broker_queue_snapshot(sample_limit=2)
        logger.warning(
            "[job-launch] enqueue success job_id=%s job_type=%s task_id=%s queue=%s queue_len_after=%s samples=%s",
            job.id,
            job_type,
            task_id,
            after_snapshot.queue_name,
            after_snapshot.length,
            after_snapshot.samples,
        )
        outcome["task_id"] = task_id

    transaction.on_commit(_enqueue)

    job.refresh_from_db()
    return JobLaunchOutcome(job=job, dispatch_error=outcome.get("dispatch_error"))


def dispatch_task_after_commit(
    *,
    task: Any,
    task_args: list[Any] | tuple[Any, ...] | None = None,
    task_kwargs: Mapping[str, Any] | None = None,
) -> TaskDispatchOutcome:
    """Publish an untracked Celery task only after the surrounding DB transaction commits."""
    args = list(task_args or [])
    kwargs = dict(task_kwargs or {})
    outcome: dict[str, Any] = {}

    def _enqueue() -> None:
        try:
            async_result = task.apply_async(args=args, kwargs=kwargs)
        except Exception as exc:  # pragma: no cover - exercised through mocks/tests
            outcome["dispatch_error"] = exc
            return

        outcome["task_id"] = (getattr(async_result, "id", "") or "")[:64]

    transaction.on_commit(_enqueue)
    return TaskDispatchOutcome(
        task_id=str(outcome.get("task_id", "")),
        dispatch_error=outcome.get("dispatch_error"),
    )
