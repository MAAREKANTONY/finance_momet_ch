"""
Backtesting engine (Feature 2 - skeleton).

This module will implement the full backtest logic in small incremental features.
For now, we only define the contract and keep it import-safe.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.models import Backtest


@dataclass
class BacktestEngineResult:
    """In-memory result returned by the engine."""
    results: dict[str, Any]
    logs: list[str]


def run_backtest(backtest: Backtest) -> BacktestEngineResult:
    """
    Run the backtest synchronously and return results.

    Notes:
    - The caller is responsible for ensuring prerequisite data (DailyBar / DailyMetric / Alert) is present.
    - In Feature 3+, this function will compute per-ticker daily series and summaries.
    """
    raise NotImplementedError("Backtest engine not implemented yet (Feature 3+).")
